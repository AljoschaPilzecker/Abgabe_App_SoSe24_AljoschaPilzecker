package com.example.remembar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Login extends AppCompatActivity {

    private EditText editTextLoginEmailAddress;
    private EditText editTextLoginPassword;
    private Button loginSaveButton;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login2);

        mAuth = FirebaseAuth.getInstance();

        editTextLoginEmailAddress = findViewById(R.id.editTextLoginEmailAddress);
        editTextLoginPassword = findViewById(R.id.editTextLoginPassword);
        loginSaveButton = findViewById(R.id.loginSaveButton);

        // OnClickListener für den Login-Button
        loginSaveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginUser();
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();

        // Überprüfung, ob Benutzer bereits angemeldet ist
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            // Wenn Benutzer bereits angemeldet ist, wird er zur Startseite weitergeleitet
            Intent goToStart = new Intent(Login.this, Start.class);
            startActivity(goToStart);
            finish();
        }
    }

    // Einloggen eines Benutzers
    private void loginUser() {
        String loginEmailAddress = editTextLoginEmailAddress.getText().toString().trim();
        String loginPassword = editTextLoginPassword.getText().toString().trim();

        // Überprüfung, ob E-Mail und Passwort eingegeben wurden
        if (TextUtils.isEmpty(loginEmailAddress)) {
            Toast.makeText(Login.this, "Enter email", Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(loginPassword)) {
            Toast.makeText(Login.this, "Enter Password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Anmeldung mit E-Mail, Passwort
        mAuth.signInWithEmailAndPassword(loginEmailAddress, loginPassword)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Wenn die Anmeldung erfolgreich ist, wird der Benutzer zur Startseite weitergeleitet
                            Toast.makeText(Login.this, "Erfolgreich angemeldet..", Toast.LENGTH_SHORT).show();
                            Intent goToStart = new Intent(Login.this, Start.class);
                            startActivity(goToStart);
                            finish();
                        } else {
                            // Wenn die Anmeldung fehlschlägt, wird eine Fehlermeldung angezeigt
                            Toast.makeText(Login.this, "Es ist ein Fehler aufgetreten.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}
