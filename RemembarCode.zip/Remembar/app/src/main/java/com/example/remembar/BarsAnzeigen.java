package com.example.remembar;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class BarsAnzeigen extends AppCompatActivity {

    private ExpandableListView barsExpandableListView;
    private BarsExpandableListAdapter adapter;
    private List<String> barHeaders;
    private HashMap<String, List<String>> barDetails;
    private DatabaseReference myRef;

    private int expandedGroupPosition = -1;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bars_anzeigen);

        // InitialisierungFirebase-Datenbank
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://remembar-app-default-rtdb.europe-west1.firebasedatabase.app");
        myRef = database.getReference("bars");

        // Initialisierung ExpandableListView etc.
        barsExpandableListView = findViewById(R.id.barsExpandableListView);
        barHeaders = new ArrayList<>();
        barDetails = new HashMap<>();

        // Initialisierung Adapters
        adapter = new BarsExpandableListAdapter(this, barHeaders, barDetails);
        barsExpandableListView.setAdapter(adapter);

        // OnGroupExpandListener zur ExpandableListView hinzufügen
        barsExpandableListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            @Override
            public void onGroupExpand(int groupPosition) {
                // Überprüfen, ob eine andere Gruppe bereits ausgeklappt ist
                if (expandedGroupPosition != -1 && expandedGroupPosition != groupPosition) {
                    //andere Gruppe ist ausgeklappt, also schließen wir sie
                    barsExpandableListView.collapseGroup(expandedGroupPosition);
                }
                // Aktualisieren der Indexposition der gerade ausgeklappten Gruppe
                expandedGroupPosition = groupPosition;
            }
        });


        Button deleteButton = findViewById(R.id.deleteButton);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int expandedGroupPosition = -1;
                int groupCount = adapter.getGroupCount();
                for (int i = 0; i < groupCount; i++) {
                    if (barsExpandableListView.isGroupExpanded(i)) {
                        expandedGroupPosition = i;
                        break;
                    }
                }
                if (expandedGroupPosition != -1) {
                    // Die ausgewählte Bar als die festlegen, die gelöscht wird
                    String selectedBarName = (String) adapter.getGroup(expandedGroupPosition);
                    adapter.setSelectedBar(selectedBarName);
                    // Adapter über Änderungen informieren
                    adapter.removeSelectedBar();
                    adapter.notifyDataSetChanged();

                    Toast.makeText(BarsAnzeigen.this, "Bar erfolgreich gelöscht", Toast.LENGTH_SHORT).show();
                } else {

                    Toast.makeText(BarsAnzeigen.this, "Bitte eine Bar auswählen, um sie zu löschen", Toast.LENGTH_SHORT).show();
                }
            }
        });


        // ValueEventListener für Abfrage der Bars aus Datenbank
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                barHeaders.clear();
                barDetails.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String nameDerBar = snapshot.child("nameDerBar").getValue(String.class);
                    String adresseDerBar = snapshot.child("adresseDerBar").getValue(String.class);
                    String anmerkungen = snapshot.child("anmerkungen").getValue(String.class);
                    boolean kickerChecked = snapshot.child("kickerChecked").getValue(Boolean.class);
                    boolean nichtraucherChecked = snapshot.child("nichtraucherChecked").getValue(Boolean.class);
                    boolean dartChecked = snapshot.child("dartChecked").getValue(Boolean.class);
                    boolean livemusikChecked = snapshot.child("livemusikChecked").getValue(Boolean.class);
                    boolean schließtChecked = snapshot.child("schließtChecked").getValue(Boolean.class);
                    boolean tischtennisChecked = snapshot.child("tischtennisChecked").getValue(Boolean.class);

                    // Hinzufügen des Bar-Namens als Header
                    barHeaders.add(nameDerBar);

                    // Erstellen der Details
                    List<String> details = new ArrayList<>();
                    details.add("Adresse: " + adresseDerBar);
                    details.add("Anmerkungen: " + anmerkungen);
                    if (kickerChecked) {
                        details.add("Kicker");
                    }
                    if (nichtraucherChecked) {
                        details.add("Nichtraucher");
                    }
                    if (tischtennisChecked) {
                        details.add("Tischtennis");
                    }
                    if (schließtChecked) {
                        details.add("Schließt wochentags nach 4");
                    }
                    if (livemusikChecked) {
                        details.add("Live-Musik");
                    }
                    if (dartChecked) {
                        details.add("Dart");
                    }
                    // Hinzufügen zur HashMap
                    barDetails.put(nameDerBar, details);
                }
                // Adapter aktualisieren
                adapter.notifyDataSetChanged();
                // ExpandableListView neu initialisieren
                barsExpandableListView.setAdapter(adapter);
                barsExpandableListView.collapseGroup(0); // Schließt die erste Gruppe
                barsExpandableListView.expandGroup(0); // Öffnet die erste Gruppe
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

                Toast.makeText(BarsAnzeigen.this, "Fehler beim Lesen der Daten: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
