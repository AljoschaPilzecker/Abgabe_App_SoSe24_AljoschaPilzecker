package com.example.remembar;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import android.view.View;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.FirebaseApp;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class NeuerEintrag extends AppCompatActivity {

    FirebaseDatabase database = FirebaseDatabase.getInstance("https://remembar-app-default-rtdb.europe-west1.firebasedatabase.app");
    DatabaseReference myRef = database.getReference("bars");
    private CheckBox checkKicker, checkNichtraucher, checkLivemusik, checkSchließt, checkTischtennis, checkDart;
    private EditText editTextNameDerBar, editTextAdresseDerBar, editTextAnmerkungen;

    private Button neuerEintragSaveButton;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_neuer_eintrag);

        FirebaseApp.initializeApp(this);



        checkKicker = findViewById(R.id.checkKicker);
        checkNichtraucher = findViewById(R.id.checkNichtraucher);
        checkLivemusik = findViewById(R.id.checkLivemusik);
        checkSchließt = findViewById(R.id.checkSchließt);
        checkTischtennis = findViewById(R.id.checkTischtennis);
        checkDart = findViewById(R.id.checkDart);
        editTextNameDerBar = findViewById(R.id.editTextText);
        editTextAdresseDerBar = findViewById(R.id.editTextTextPostalAddress);
        editTextAnmerkungen = findViewById(R.id.editTextAnmerkungen);
        neuerEintragSaveButton = findViewById(R.id.neuerEintragSaveButton);

        neuerEintragSaveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String toastMessage = getNeuerEintrag().nameDerBar + " gespeichert!";
                Toast.makeText(NeuerEintrag.this, toastMessage, Toast.LENGTH_SHORT).show();

                Intent goToStart = new Intent(NeuerEintrag.this, Start.class);
                startActivity(goToStart);

                NeuerEintragModel eintrag = getNeuerEintrag();
                String key = myRef.push().getKey();
                myRef.child(key).setValue(eintrag);

            }
            public NeuerEintragModel getNeuerEintrag() {
                String nameDerBar = editTextNameDerBar.getText().toString();
                String adresseDerBar = editTextAdresseDerBar.getText().toString();
                boolean kickerChecked = checkKicker.isChecked();
                boolean nichtraucherChecked = checkNichtraucher.isChecked();
                boolean livemusikChecked = checkLivemusik.isChecked();
                boolean schließtChecked = checkSchließt.isChecked();
                boolean tischtennisChecked = checkTischtennis.isChecked();
                boolean dartChecked = checkDart.isChecked();
                String anmerkungen = editTextAnmerkungen.getText().toString();


                return new NeuerEintragModel(nameDerBar, adresseDerBar, kickerChecked,
                        nichtraucherChecked, livemusikChecked, schließtChecked,
                        tischtennisChecked, dartChecked, anmerkungen);
            }
            class NeuerEintragModel {
                public String nameDerBar;
                public String adresseDerBar;
                public boolean kickerChecked;
                public boolean nichtraucherChecked;
                public boolean livemusikChecked;
                public boolean schließtChecked;
                public boolean tischtennisChecked;
                public boolean dartChecked;
                public String anmerkungen;

                // Konstruktor
                NeuerEintragModel(String nameDerBar, String adresseDerBar, boolean kickerChecked,
                                  boolean nichtraucherChecked, boolean livemusikChecked, boolean schließtChecked,
                                  boolean tischtennisChecked, boolean dartChecked, String anmerkungen) {
                    this.nameDerBar = nameDerBar;
                    this.adresseDerBar = adresseDerBar;
                    this.kickerChecked = kickerChecked;
                    this.nichtraucherChecked = nichtraucherChecked;
                    this.livemusikChecked = livemusikChecked;
                    this.schließtChecked = schließtChecked;
                    this.tischtennisChecked = tischtennisChecked;
                    this.dartChecked = dartChecked;
                    this.anmerkungen = anmerkungen;
                }

                public String getNameDerBar() {
                    return nameDerBar;
                }

                public String getAdresseDerBar() {
                    return adresseDerBar;
                }

                public String getAnmerkungen() {
                    return anmerkungen;
                }

                public boolean isKickerChecked() {
                    return kickerChecked;
                }

                public boolean isDartChecked() {
                    return dartChecked;
                }

                public boolean isLivemusikChecked() {
                    return livemusikChecked;
                }

                public boolean isNichtraucherChecked() {
                    return nichtraucherChecked;
                }

                public boolean isSchließtChecked() {
                    return schließtChecked;
                }

                public boolean isTischtennisChecked() {
                    return tischtennisChecked;
                }
            }

        });}}