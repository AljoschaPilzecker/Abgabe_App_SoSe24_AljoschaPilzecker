package com.example.remembar;

import android.widget.CheckBox;
import android.widget.EditText;

public class NeuerEintragModel {

    public CheckBox checkKicker, checkNichtraucher, checkLivemusik, checkSchließt, checkTischtennis, checkDart;
    public EditText editTextNameDerBar, editTextAdresseDerBar, editTextAnmerkungen;

        public String nameDerBar;
        public String adresseDerBar;
        public boolean kickerChecked;
        public boolean nichtraucherChecked;
        public boolean livemusikChecked;
        public boolean schließtChecked;
        public boolean tischtennisChecked;
        public boolean dartChecked;
        public String anmerkungen;


        NeuerEintragModel(String nameDerBar, String adresseDerBar, boolean kickerChecked,
                          boolean nichtraucherChecked, boolean livemusikChecked, boolean schließtChecked,
                          boolean tischtennisChecked, boolean dartChecked, String anmerkungen) {
            this.nameDerBar = nameDerBar;
            this.adresseDerBar = adresseDerBar;
            this.kickerChecked = kickerChecked;
            this.nichtraucherChecked = nichtraucherChecked;
            this.livemusikChecked = livemusikChecked;
            this.schließtChecked = schließtChecked;
            this.tischtennisChecked = tischtennisChecked;
            this.dartChecked = dartChecked;
            this.anmerkungen = anmerkungen;
        }


        public NeuerEintragModel erstelleNeuenEintrag() {
            String nameDerBar = editTextNameDerBar.getText().toString();
            String adresseDerBar = editTextAdresseDerBar.getText().toString();
            boolean kickerChecked = checkKicker.isChecked();
            boolean nichtraucherChecked = checkNichtraucher.isChecked();
            boolean livemusikChecked = checkLivemusik.isChecked();
            boolean schließtChecked = checkSchließt.isChecked();
            boolean tischtennisChecked = checkTischtennis.isChecked();
            boolean dartChecked = checkDart.isChecked();
            String anmerkungen = editTextAnmerkungen.getText().toString();


            return new NeuerEintragModel(nameDerBar, adresseDerBar, kickerChecked,
                    nichtraucherChecked, livemusikChecked, schließtChecked,
                    tischtennisChecked, dartChecked, anmerkungen);
        }

        public String getNameDerBar() {
            return nameDerBar;
        }

        public String getAdresseDerBar() {
            return adresseDerBar;
        }

        public String getAnmerkungen() {
            return anmerkungen;
        }
    public boolean isKickerChecked() {
        return kickerChecked;
    }

    public boolean isDartChecked() {
        return dartChecked;
    }

    public boolean isLivemusikChecked() {
        return livemusikChecked;
    }

    public boolean isNichtraucherChecked() {
        return nichtraucherChecked;
    }

    public boolean isSchließtChecked() {
        return schließtChecked;
    }

    public boolean isTischtennisChecked() {
        return tischtennisChecked;
    }
    }


