package com.example.remembar;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.content.Intent;
import android.view.View;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;


public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    Button goToRegisterButton = findViewById(R.id.goToRegisterButton);
    Button goToLoginButton = findViewById(R.id.goToLoginButton);



        goToRegisterButton.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View view) {
            Intent gotoRegistrieren = new Intent (MainActivity.this, Registrieren.class);
            startActivity(gotoRegistrieren);

        }
                                          });
         goToLoginButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent gotoLogin = new Intent (MainActivity.this, Login.class);
                    startActivity(gotoLogin);

                }
    });
       /* auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        //textView = findViewById(R.id.user_details);
        if (user == null){
            Intent intent = new Intent(getApplicationContext(), Login.class);
            startActivity(intent);
            finish();
        }
        else {

        }*/
}
    }


